addappid(236390)
addappid(236391, 1, "a6b3cd630da5dc58205f88ebc974d7cfb462e98bf51c716796ef57fbe222a8cf")
setManifestid(236391, "108451390819705241", 0)
addappid(236392, 1, "d28ecfa5efd92fa7a5648a3083ca753c508e85ef28c56e64a3cdd75692147afd")
setManifestid(236392, "8774376141645705524", 0)
addappid(236393, 1, "96647011e1f9d79b47fee098f8c5dc9675ca132a118dec941a5a8682812da58d")
setManifestid(236393, "5230125255430301241", 0)
addappid(236394, 1, "000c645c4187c9a4be937ac13100738fd2b80bd63db3c54800fb897877960aa8")
setManifestid(236394, "1629032567588361943", 0)


addappid(244230) -- War Thunder - Steam Pack
addappid(244350) -- War Thunder - Mustang Advanced Pack
addappid(244370) -- War Thunder - Dora Advanced Pack
addappid(244390) -- War Thunder - Ace Advanced Pack
addappid(271000) -- War Thunder - Melting Snowflake
addappid(271001) -- War Thunder - Frosty Snowflake
addappid(271002) -- War Thunder - Refulgent Snowflake
addappid(271003) -- War Thunder - Sparkling Snowflake
addappid(271004) -- War Thunder - Shining Snowflake
addappid(271005) -- War Thunder - Perfect Snowflake
addappid(305221) -- War Thunder - Shielded T-34E Advanced Pack
addappid(311600) -- War Thunder - Tank Destroyers Advanced Pack
addappid(354700) -- War Thunder - Fire and Maneuver Advanced Pack
addappid(354701) -- War Thunder - Grant I Advanced Pack
addappid(354702) -- War Thunder - Dora Advanced Pack
addappid(383760) -- War Thunder - Defenders Advanced Pack
addappid(402270) -- War Thunder - Alienware Bundle Pack
addappid(408040) -- War Thunder - T-34-85E Advanced Pack
addappid(408041) -- War Thunder - Ray Wetmore`s P-51D-10 Advanced Pack
addappid(425780) -- War Thunder - Spitfire FR Mk.XIVe Advanced Pack
addappid(425790) -- War Thunder - М5А1 Starter Pack
addappid(425791) -- War Thunder - Red Fury Advanced Pack
addappid(477820) -- War Thunder - Desert Rats Pack
addappid(477821) -- War Thunder - Panzer Pack
addappid(602470) -- War Thunder - US Combined Forces
addappid(602471) -- War Thunder - Royal Combined Forces
addappid(602472) -- War Thunder - Kliment Voroshilov Pack
addappid(795731) -- War Thunder - Plagis' Spitfire LF Mk. IX
addappid(795732) -- War Thunder - T29 Pack
addappid(797220) -- War Thunder - Guards T-34 Pack
addappid(891300) -- War Thunder - Ray Wetmore`s P-51D-10 Pack
addappid(891301) -- War Thunder - Black Prince Pack
addappid(891302) -- War Thunder - Hunter Pack
addappid(983440) -- War Thunder - T-34-85E, 1945 Pack
addappid(983441) -- War Thunder - M18 Black Cat Pack
addappid(983442) -- War Thunder - Sergei Dolgushin's La-7 Pack
addappid(1108450) -- War Thunder - US Starter Pack
addappid(1233370) -- War Thunder - USSR Beginner's Pack
addappid(1233371) -- War Thunder - German Beginner's Pack
addappid(1233372) -- War Thunder - Huey Hog Pack
addappid(1233373) -- War Thunder - Haida Pack
addappid(1243020) -- War Thunder - British Beginner's Pack
addappid(1243021) -- War Thunder - Japanese Beginner's Pack
addappid(1331220) -- War Thunder - XM-1 General Motors Pack
addappid(1331221) -- War Thunder - Apache Pack
addappid(1347610) -- War Thunder - Leopard Pack
addappid(1347611) -- War Thunder - T-55AM-1 Pack
addappid(1364970) -- War Thunder - USA Pacific Campaign
addappid(1364971) -- War Thunder - Japanese Pacific Campaign
addappid(1368110) -- War Thunder - Italian Starter Pack
addappid(1368800) -- War Thunder - Japanese Starter Pack
addappid(1368801) -- War Thunder - British Starter Pack
addappid(1415530) -- War Thunder - USA Pacific Campaign (YP-38)
addappid(1423760) -- War Thunder - French Starter Pack
addappid(1478150) -- War Thunder - Black Friday Pack
addappid(1478810) -- War Thunder - T-72AV (TURMS-T) Pack
addappid(1557850) -- War Thunder - Black Shark Pack
addappid(1557851) -- War Thunder - German Fiat G.91 R/4 Pack
addappid(1566970) -- War Thunder - Reaper Pack
addappid(1566971) -- War Thunder - Rooikat 105 pack
addappid(1582830) -- War Thunder - Swedish Starter Pack
addappid(1657120) -- War Thunder - F-5C Pack
addappid(1845540) -- War Thunder - Su-7BMK Pack
addappid(1845541) -- War Thunder - MiG-21 SPS-K Pack
