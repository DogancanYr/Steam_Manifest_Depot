addappid(578080)
addappid(578081, 1, "74eea6f9f5b0c0deea249bea435370fe734f552a55e1aca5b09ff4f3990ad53e")
setManifestid(578081, "774566788704272669", 0)
addappid(578082, 1, "6cbd9e8da0339346aeaafb966fd6a173ee898929b9ba4349550c5489234dbac7")
setManifestid(578082, "6203426191546330616", 0)


addappid(888770) -- Event Pass: Sanhok
addappid(990650) -- Survivor Pass: Vikendi
addappid(1046180) -- Survivor Pass 3: Wild Card
addappid(1113910) -- Survivor Pass 4: Aftermath
addappid(1145250) -- Survivor Pass: Badlands
addappid(1222520) -- Survivor Pass: Shakedown
addappid(1273370) -- Survivor Pass: Cold Front
addappid(1349770) -- Survivor Pass: Payback
addappid(1414050) -- Survivor Pass: Highlands
addappid(1477540) -- Survivor Pass: Breakthrough
addappid(1737770) -- PUBG Gilt Elegance-1,050 G-Coin Skin Pack
addappid(1776090) -- PUBG legacy rewards
addappid(3639460) -- Publisher Sale - Summer Ready Pack
