addappid(730)
addappid(731, 1, "bca9a9cde94bb4dff61849c6a87230ee45867a590fdd28826366e35e7d62c08e")
setManifestid(731, "1224088799001669801", 0)
addappid(732, 1, "da1f76913633e9ce1b2bda5ec464dc507205388fac5c4c614b6a2706cdbd0912")
setManifestid(732, "6314304446937576250", 0)
addappid(733, 1, "23c8e9a91561a5fb08abf22f2ac98929f4aad68a12164268d3b2800c3db4fb03")
setManifestid(733, "7818492753742006607", 0)
addappid(734, 1, "54fd243c5463c16ec7d32b5b4c7b792b3f2d3f75009ac3e81135ff999b56187f")
setManifestid(734, "3343055176458696864", 0)
addappid(735, 1, "a0ef69f0cf8abd70aa9ed79755fbe4d98cf7c6723ba9e0c66e0f7102e49541e6")
setManifestid(735, "3867231304834558645", 0)


addappid(1490530) -- Counter-Strike: Global Offensive - Operation Broken Fang
addappid(1766730) -- CS:GO - Operation Riptide
addappid(2279720) -- Counter-Strike 2 (Limited Test)
