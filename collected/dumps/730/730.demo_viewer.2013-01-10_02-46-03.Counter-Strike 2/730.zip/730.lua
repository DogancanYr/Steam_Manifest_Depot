addappid(730)
addappid(731, 1, "bca9a9cde94bb4dff61849c6a87230ee45867a590fdd28826366e35e7d62c08e")
setManifestid(731, "8917601652689682225", 0)
addappid(732, 1, "da1f76913633e9ce1b2bda5ec464dc507205388fac5c4c614b6a2706cdbd0912")
setManifestid(732, "5384752978584135997", 0)
addappid(733, 1, "23c8e9a91561a5fb08abf22f2ac98929f4aad68a12164268d3b2800c3db4fb03")
setManifestid(733, "2103093205873127583", 0)


addappid(1490530) -- Counter-Strike: Global Offensive - Operation Broken Fang
addappid(1766730) -- CS:GO - Operation Riptide
addappid(2279720) -- Counter-Strike 2 (Limited Test)
