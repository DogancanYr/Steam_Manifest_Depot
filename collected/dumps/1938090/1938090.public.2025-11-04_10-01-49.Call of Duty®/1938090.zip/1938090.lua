addappid(1938090)
addappid(1938091, 1, "f793d14324c44b23e03af1297626dc11756f9d2d8c77d510f3399e468fff5e87")
setManifestid(1938091, "3457909063602293714", 0)
addappid(1938092, 1, "94172c4bdb1ed3af957ce904a340f691e4c584b83c9c4eae0ffea087903c8811")
setManifestid(1938092, "1603076934971087884", 0)
addappid(1938093, 1, "1a6d275cae735b6211a80c061b9114975c314d9b48d49e1ea59c2f0300e79594")
setManifestid(1938093, "8743617432567747182", 0)
addappid(1938094, 1, "3d8bc7e330752517ed81ea79390774df78c1e22086fe9236b3af7451f704b82d")
setManifestid(1938094, "3919603122545671859", 0)
addappid(1938095, 1, "8e9608f26d2b69a10803656803af2ab82e5e826f74eede37d50e554744b7c315")
setManifestid(1938095, "8594832729951860367", 0)
addappid(1938096, 1, "d7d9e68cd3cd39c5788e7d9c9e0e4d98a1560a4f4ffcec9059a11609536172df")
setManifestid(1938096, "6440129038500045199", 0)
addappid(1938097, 1, "f156a97430bff785f4578cc51b9abedc8ab30b18f228228240ef8d52905b4eda")
setManifestid(1938097, "4811219465498049846", 0)
addappid(1938098, 1, "9a815daf492e1f8b89ca4eb8247556cfe8fe84cd0782fdd20c0e7b9647f4b3e4")
setManifestid(1938098, "2440138305741781751", 0)
addappid(1938099, 1, "331dfd5d753906f1b0ad27ac8b11a76b8ab87f727d7482c378d306a3fdbdcefc")
setManifestid(1938099, "9123183746377397258", 0)
addappid(1962663, 1, "9ee98dd59c765f15905de46699cc4f70674dc78a00bc643762b822a7cbc423af")
setManifestid(1962663, "6997425334532933126", 0)
addappid(1962664, 1, "1962e3261e637409ece6aa676f6f9331ca3e15d68ccb7e77f0c94f8658e33263")
setManifestid(1962664, "8070250693681575150", 0)
addappid(1962665, 1, "0741c99309ab5df6228a27f372df18b93816730d39a2c64c39e9d312d198b4d4")
setManifestid(1962665, "1761307039445995575", 0)
addappid(1962666, 1, "e9f934cb4d5dffe11e762c3a98f3da829ed4ae3835017208d5ad3484342840e5")
setManifestid(1962666, "5276562104387015192", 0)
addappid(1962667, 1, "3aa6e37ed947867ff526495e2794b33a564221636ffeec31a32ea0e1a719762e")
setManifestid(1962667, "3886340895617877467", 0)
addappid(1962668, 1, "be295421ce3ac5eb7b16d3cbea6c4eccb16ea6571578b81f39baec3720c339e9")
setManifestid(1962668, "306572425337826589", 0)
addappid(1962669, 1, "f0cbf3925a35f79cd4db0bb3694b579eacdbda5dc18e9beb972d351d532d0e5f")
setManifestid(1962669, "5150815568925829458", 0)
addappid(2014030, 1, "88bf51a1edb0725fc2d045e6d548e6aba70305849524d47e5f34edcf790b0f25")
setManifestid(2014030, "5962784157782008454", 0)
addappid(2014031, 1, "86e1ff16cfce1a3f2c7edcd795219dc17663bd4a2faf7e3cde2e4937f005d5f3")
setManifestid(2014031, "7814281104745298882", 0)
addappid(2014074, 1, "2bd5a597b6df47ddcea3d5194a6389657b2eacc9bc9426053accc39c0d886eb9")
setManifestid(2014074, "4415133877345297189", 0)
addappid(2014075, 1, "a67fb302920247b503eb9c5654b122acb01c5008a8552d7a68ab3b1df4f8b4ca")
setManifestid(2014075, "4603513902699420253", 0)
addappid(2014076, 1, "d68616b127640a7dc39d317924cf42e06fd8fd29e95f1994f0560d00435e9156")
setManifestid(2014076, "7507718209042618104", 0)
addappid(2014077, 1, "4900105a340dfcc959640a527932059a510285ad8c77dd03605e00ff6c396bef")
setManifestid(2014077, "4828338844160357741", 0)
addappid(2014078, 1, "4b6e90c7454e428fc0484bd20be2fef85d1ca9ddb7e298878c9b7651257bb447")
setManifestid(2014078, "7557639337366236485", 0)
addappid(2014079, 1, "22bb00be3143d031a3681b88cfb5e10cebbce73c1f89bb02dd607cbc684ca814")
setManifestid(2014079, "8990481104130045660", 0)
addappid(2014080, 1, "1d434e3088f906b491524b3ce5776eb7987001ef59371e0430019e94ebcd7591")
setManifestid(2014080, "196404946916101578", 0)
addappid(2014081, 1, "affbb1f94521122e9e8945392526924f729fc65846276e9d91ba57b9bb76c510")
setManifestid(2014081, "1003367506555708527", 0)
addappid(2014082, 1, "6c9cf8c3c1d8ea6859f50d21bc02f35d4b6b6b34dc4fc562dd8599d33b57c3d1")
setManifestid(2014082, "994014740797067907", 0)
addappid(2014083, 1, "188fea7bf854aef756ecd6f1e808b4fb20af69156f855de78aba6d09751eb9d7")
setManifestid(2014083, "3604351218399467807", 0)
addappid(2014084, 1, "ed6db1f6280316f33e6d4adeca3d09e8fa86b21b9e36757db1742f2f1172d221")
setManifestid(2014084, "6114737517867401435", 0)
addappid(2014085, 1, "79b5ab86a650727ae6f3cd6ac58da17a2c1a0960e1373706e8dff7fd8e2bb65b")
setManifestid(2014085, "2107705998439718584", 0)
addappid(2014086, 1, "3c64215033d51aad59e7dd4158d1ff8776bdb02bd9f6e0327011af260dc182a3")
setManifestid(2014086, "1751496697678115076", 0)
addappid(2014087, 1, "acf3780d1de03f675658607f1293d010cffdd9acd7bca5c458df2f9bca8a8c08")
setManifestid(2014087, "3519185432014366470", 0)
addappid(2014267, 1, "894638ffc3c3f138926d08245fc8f43bf5e1cd5f51fc203c9b8912177ab20b80")
setManifestid(2014267, "1001966697753856996", 0)
addappid(2021995, 1, "f80041120508fd0fe83f89c013b93bbae03dafc837cc4564cd090b905e9896c5")
setManifestid(2021995, "1014279665744904844", 0)
addappid(2053672, 1, "abcf1a0bf941c4e26b136966dd082ba84b505c14d6e80c37bc88872df02d51bf")
setManifestid(2053672, "5644099161056449653", 0)
addappid(2170979, 1, "53058b2d01c9d2b5e804da7613bcdc7b32760bbb07bdb113503f4d448cc527d4")
setManifestid(2170979, "4006118253986548597", 0)
addappid(2228971, 1, "8d6a5b7558ef323319ed8be8a81debfbae3e65577e191c1c86be9ad7ffe3e900")
setManifestid(2228971, "7047412874517125477", 0)
addappid(2228972, 1, "25828e7e3e8a4d2b2b6bed7c8c4a0ee099ff5928a74bf0a40d694696d75181be")
setManifestid(2228972, "6635242755707983152", 0)
addappid(2228973, 1, "ac9d7ab502e6ccbd4c03c5e177b3fa5622add54a262a97c107de73e8669ef188")
setManifestid(2228973, "2103177727177200797", 0)
addappid(2228974, 1, "8d5c90d1f5f3930c35f8d1c1caeed84252cf66362bf2c807062e487473df0a26")
setManifestid(2228974, "7231415685147320238", 0)
addappid(2228975, 1, "64bded1983f71ce7f2c1c3a8bbd99c8d80170e6a724bb8f0d35d0e0206dc6bbd")
setManifestid(2228975, "9116351298283685848", 0)
addappid(2228976, 1, "02f0d235f596d64463d7ab60f2d217147e4894c9744f48f055df550f19e1df16")
setManifestid(2228976, "9026286542733486684", 0)
addappid(2228977, 1, "ff602c9a073705b6cd35b938c6f99503f524976476d9a0f197f8a32a2f233088")
setManifestid(2228977, "3949219351155430153", 0)
addappid(2228978, 1, "50823566bc4d4af3d209c04080157f2ea7623c1294472f4438f14e2e7d114cfc")
setManifestid(2228978, "410030948822456337", 0)
addappid(2228979, 1, "30ebd541761d62889404a87c2fa58218b1f8a7c615a6a8fa41ef82420b400f6b")
setManifestid(2228979, "7263487395571039121", 0)
addappid(2278283, 1, "67d981a72e747b1ada2b72ef1275a2fdb37c505f38809b50d5ad55632d7cfd24")
setManifestid(2278283, "6123557969831261018", 0)
addappid(2278284, 1, "131fdb519bc7704e2b9da031026ddf9a91ee051c6d2c13c5c6feedee97cadd09")
setManifestid(2278284, "463956135500129605", 0)
addappid(2278285, 1, "7fbc7f169a90737c036cbe95f1aa586acf332bf662ef223a4f133d4ca3e831e9")
setManifestid(2278285, "3450100520792418120", 0)
addappid(2278286, 1, "27317253733813c1a4f4354b1377168fb9c0ee62a3332802458fe2c6ec356fe0")
setManifestid(2278286, "8920287769079100473", 0)
addappid(2278287, 1, "0096a7a908c0062230badf549f6ec9bb04384a115aa41ad3597aee4597c7006f")
setManifestid(2278287, "8780685411682968744", 0)
addappid(2278288, 1, "3267aa8155852570fab668612e8b66226ece52457b7b9132cc12c1d4da5109b0")
setManifestid(2278288, "6631010313589881432", 0)
addappid(2278289, 1, "1cd9de16ab9ba14a37b2057030a3d9a54697db0c9a368d6cf54695b2bac22d59")
setManifestid(2278289, "3741007665795577574", 0)
addappid(2316851, 1, "69781d72df71492ad0ddc312c5875c9278e5dc37d67e05d4e91bba4bd14508de")
setManifestid(2316851, "3154661505174281350", 0)
addappid(2790671, 1, "98dddceccb8e020306c9f4d2cd5a7177eac56d0c8ce3b6399e981d920d464344")
setManifestid(2790671, "3676139934351433111", 0)
addappid(2790672, 1, "89c8af037255a48bcddd637c0ec5c0e510b021a706f3d5a3c65ae6f8185d7169")
setManifestid(2790672, "8703777060254000174", 0)
addappid(2790673, 1, "92bfb9dad7e2bd419a19ab3e5f62273c99771470fa775368335384f955dc19c3")
setManifestid(2790673, "3298930612515236257", 0)
addappid(2790674, 1, "ec94f5c2ed69cdf7db5381f72413c7f1d756225b101d898fdf67a8467e6f582f")
setManifestid(2790674, "8945803607852089297", 0)
addappid(2790675, 1, "2b10f4944edcddc8314c2b3afc3332c82503d69ebab4f195c20475a4ade35f7d")
setManifestid(2790675, "2354374207572947402", 0)
addappid(2790676, 1, "80e48a75001fc2b503c05169284dcc0624413bc33d6890246472611ced82b9e5")
setManifestid(2790676, "6453897672755191236", 0)
addappid(2790677, 1, "7a40b4790e66c28ca351341085a72a98e094981acad39b33b68505705096c418")
setManifestid(2790677, "8332574034248800090", 0)
addappid(2790678, 1, "908acbfff78ee9aa4ad133c23f1a0c24e629c4a3de5d6b05ad3563bfb33a5954")
setManifestid(2790678, "6482121332880197987", 0)
addappid(2790679, 1, "3869ef995a1ec7afb793133c69cf5676a2e6cfe017d8ae66b6989706419d7e18")
setManifestid(2790679, "1201301264013619255", 0)
addappid(2790690, 1, "0363564e4c4adced471055c68b1166f2ccf333a5586cf4b0bf509fc4a40f7ea6")
setManifestid(2790690, "3265824874182779946", 0)
addappid(2790691, 1, "32f6cca66e984d9cc473678cfa0eab427c0013d4041aa1dd0b8db8ef5f0aa39d")
setManifestid(2790691, "5567812640630715537", 0)
addappid(2790694, 1, "ffdffff37e8505310f5e8957ed228ad148fd4ed531e228f0482134f72aefeba3")
setManifestid(2790694, "4567695997181479105", 0)
addappid(2790695, 1, "13de0aa7b39d5e2921375a6cdba538a800d8c8f3bcdf5fb60c847f57ca86be7f")
setManifestid(2790695, "2574029733169267433", 0)
addappid(2790696, 1, "b820c690739dbc97d96ecf7e708b8db761eb834bf95ef4787e2453bf5e0001cd")
setManifestid(2790696, "3164917684534554793", 0)
addappid(2790697, 1, "2e17d0d1917fedefcaad3622026eec5eeca997e89473c885e26d74146143bce7")
setManifestid(2790697, "8146512455969469469", 0)
addappid(2790698, 1, "ff44e2e400c0411ba0605470cfd6fc89dfca5b10e6e5a2522e8333fdc23ddc1d")
setManifestid(2790698, "4862175940699628387", 0)
addappid(2790699, 1, "f5ec820efb02c8c2d07d2218083c82dc2336c961d1174dcecfce59fc1c52a95b")
setManifestid(2790699, "6114845781751631360", 0)
addappid(3180215, 1, "4530bdd8ef2f76f52beede87b8df90ab58beae145f5df64a02b69df45e4a496b")
setManifestid(3180215, "3527910619976551851", 0)


addappid(2014260) -- Ghost Legacy Pack
addappid(2021990) -- Call of Duty®: Modern Warfare® II - Vault Edition Pack
addappid(2053670) -- Call of Duty Endowment (C.O.D.E.) - Perseverance Pack
addappid(2053671) -- Call of Duty Endowment (C.O.D.E.) - Protector Pack
addappid(2062850) -- Final Judgement Bundle
addappid(2120530) -- Khaled Al-Asad Operator Bundle
addappid(2127790) -- Call of Duty®: Modern Warfare® II - Desert Rogue: Pro Pack
addappid(2127791) -- Call of Duty®: Modern Warfare® II - Dune Stalker: Starter Pack
addappid(2137910) -- Call of Duty®: Modern Warfare® II - Urban Veteran: Pro Pack
addappid(2139260) -- Call of Duty League™ - Launch Pack
addappid(2139261) -- Call of Duty League™ - Atlanta FaZe Pack 2023
addappid(2139262) -- Call of Duty League™ - Boston Breach Pack 2023
addappid(2139263) -- Call of Duty League™ - Florida Mutineers Pack 2023
addappid(2139264) -- Call of Duty League™ - London Royal Ravens Pack 2023
addappid(2139265) -- Call of Duty League™ - Los Angeles Guerrillas Pack 2023
addappid(2139266) -- Call of Duty League™ - Los Angeles Thieves Pack 2023
addappid(2139267) -- Call of Duty League™ - Minnesota ROKKR Pack 2023
addappid(2139268) -- Call of Duty League™ - New York Subliners Pack 2023
addappid(2139269) -- Call of Duty League™ - OpTic Texas Pack 2023
addappid(2139270) -- Call of Duty League™ - Vegas Legion Pack 2023
addappid(2139271) -- Call of Duty League™ - Seattle Surge Pack 2023
addappid(2139272) -- Call of Duty League™ - Toronto Ultra Pack 2023
addappid(2170970) -- Call of Duty®: Black Ops 7 or Call of Duty®: Warzone™ Points
addappid(2228970) -- Call of Duty®: Modern Warfare® II - BlackCell (Season 03)
addappid(2278280) -- Call of Duty®: Modern Warfare® II - Itadakimasu: Starter Pack
addappid(2316850) -- Call of Duty®: Modern Warfare® II - Manticore: Pro Pack
addappid(2332010) -- Call of Duty League™ - Atlanta FaZe Team Pack 2023
addappid(2332011) -- Call of Duty League™ - Boston Breach Team Pack 2023
addappid(2332012) -- Call of Duty League™ - Florida Mutineers Team Pack 2023
addappid(2332013) -- Call of Duty League™ - London Royal Ravens Team Pack 2023
addappid(2332014) -- Call of Duty League™ - Los Angeles Guerrillas Team Pack 2023
addappid(2332015) -- Call of Duty League™ - Los Angeles Thieves Team Pack 2023
addappid(2332016) -- Call of Duty League™ - Minnesota ROKKR Team Pack 2023
addappid(2332017) -- Call of Duty League™ - New York Subliners Team Pack 2023
addappid(2332018) -- Call of Duty League™ - OpTic Texas Team Pack 2023
addappid(2332019) -- Call of Duty League™ - Vegas Legion Team Pack 2023
addappid(2332020) -- Call of Duty League™ - Seattle Surge Team Pack 2023
addappid(2332021) -- Call of Duty League™ - Toronto Ultra Team Pack 2023
addappid(2354080) -- Call of Duty Endowment (C.O.D.E.) - Valkyrie Pack
addappid(2387940) -- Call of Duty®: Modern Warfare® II - Demon Deer: Pro Pack
addappid(2396440) -- Call of Duty®: Modern Warfare® II - BlackCell (Season 04)
addappid(2396490) -- Call of Duty®: Modern Warfare® II - Griffin: Pro Pack
addappid(2433000) -- Call of Duty®: Modern Warfare® II - Graffiti Tactical: Pro Pack
addappid(2451950) -- Call of Duty®: Modern Warfare® II - BlackCell (Season 05)
addappid(2459970) -- Call of Duty®: Modern Warfare® II - Gunslinger Ghost: Pro Pack
addappid(2493660) -- Call of Duty®: Modern Warfare® II - Cosmic Traveler: Pro Pack
addappid(2519090) -- Call of Duty®: Modern Warfare® III - Standard Pack 1
addappid(2519100) -- Call of Duty®: Modern Warfare® III - Vault Pack 1
addappid(2531820) -- Call of Duty®: Modern Warfare® II - BlackCell (Season 06)
addappid(2534810) -- Call of Duty®: Modern Warfare® II - Pumpkin Patch: Pro Pack
addappid(2540870) -- Call of Duty®: Modern Warfare® III - Vault Pack 2
addappid(2540890) -- Call of Duty®: Modern Warfare® III - Vault Beta Pack 1
addappid(2540900) -- Call of Duty®: Modern Warfare® III - Vault Pack 4
addappid(2540910) -- Call of Duty®: Modern Warfare® III - Vault Pack 5
addappid(2540920) -- Call of Duty®: Modern Warfare® III - Standard Pack 2
addappid(2596430) -- Call of Duty Endowment (C.O.D.E.) Warrior Pack
addappid(2596440) -- Call of Duty®: Modern Warfare® III - BlackCell (Season 1)
