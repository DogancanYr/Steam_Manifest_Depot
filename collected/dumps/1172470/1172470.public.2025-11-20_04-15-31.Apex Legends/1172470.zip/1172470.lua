addappid(1172470)
addappid(1172471, 1, "07aa3be059db58b5721e17cb3e8c90e03a1905aff70010a5f797a2f993516984")
setManifestid(1172471, "8582252571994157124", 0)
addappid(1172472, 1, "2d8c2248b6a32f060a98833b794bfe1389f8013990e15270fd37d5f6afb919ec")
setManifestid(1172472, "776090649501518374", 0)
addappid(1172473, 1, "6a56a233dd8485b7ff6e653cbad3936a1bc6b401e23c3cfa2344f1af820bed37")
setManifestid(1172473, "8969710595560526057", 0)
addappid(1172474, 1, "62fd173e23d67c4f6ca3f00eb389a16caf7d02997a61bc022876410e1396cfab")
setManifestid(1172474, "833849851994386346", 0)
addappid(1172475, 1, "1cc5c1dfd724bccf46f21245f637b41ce56dc94e6d87f13cadfa0bb1b4642eb2")
setManifestid(1172475, "6933433294990550718", 0)
addappid(1172476, 1, "2c7bc15467491f509af58c3865003c3e841699d902300953fb76310f0c582460")
setManifestid(1172476, "8370833461677771715", 0)
addappid(1172477, 1, "850186824241bbe7e4fcb22cf90f3225591834496905d2946d45d1d8e4210dbc")
setManifestid(1172477, "4549288006059789678", 0)
addappid(1172478, 1, "a08e1070c2beb20e95f9339404827e903df22cdbf0b91b17ce3990c110e8313c")
setManifestid(1172478, "6396758973797316177", 0)
addappid(1172479, 1, "35edf936f063125939e06eaaa66ab4b6be58dc79af9c8aab5bde08c942a303cb")
setManifestid(1172479, "2103920443167190647", 0)
addappid(1311105, 1, "70fc46e692a1da85e402ead6bfce0fc11831de7b9597a24ec40cff53b0c698d7")
setManifestid(1311105, "6048415564646653751", 0)


addappid(1311090) -- Apex Legends™ - Lifeline Edition
addappid(1311091) -- Apex Legends™ - Bloodhound Edition
addappid(1311092) -- Apex Legends™ - Lifeline and Bloodhound Double Pack
addappid(1311094) -- Apex Legends™ – 2000 (+150 Bonus*!) Apex Coins
addappid(1311098) -- Apex Legends™ - Octane Edition
addappid(1311100) -- Apex Legends™ - Lifeline- Content
addappid(1311101) -- Apex Legends™ - Bloodhound - Content
addappid(1311102) -- Apex Legends™ - Octane Edition Content
addappid(1440320) -- Apex Legends™ - Ascension Pack Bundle
addappid(1445900) -- Apex Legends™ - Champion Content
addappid(1445930) -- Apex Legends™ - Pathfinder Content
addappid(1445950) -- Apex Legends™ - Pathfinder Edition
addappid(1445990) -- Apex Legends™ - Champion Edition
addappid(1465730) -- Apex Legends™ Pathfinder – 1,000 Apex Coins
addappid(1465731) -- Apex Legends™ Octane – 1,000 Apex Coins
addappid(1465732) -- Apex Legends™ Bloodhound – 1,000 Apex Coins
addappid(1465733) -- Apex Legends™ Lifeline – 1,000 Apex Coins
addappid(1465734) -- Apex Legends™ Champion – 1,000 Apex Coins
addappid(1467350) -- Apex Legends™ - Gibraltar Edition
addappid(1479451) -- Apex Legends™ - Mirage Edition
addappid(1479453) -- Apex Legends™ - Escape Pack
addappid(1479454) -- Apex Legends™ - Mayhem Pack
addappid(1576330) -- Apex Legends™ - Legacy Pack
addappid(1622670) -- Apex Legends™ - Emergence Pack
addappid(1623570) -- Apex Legends™ - Bangalore Edition
addappid(1623571) -- Apex Legends™ - Loba Edition
addappid(1831300) -- Apex Legends™ – Defiance Pack
addappid(1948850) -- Apex Legends™ – Saviors Pack
addappid(3403260) -- Apex Legends™: Ash Free Unlock Bundle
