addappid(386360)
addappid(386361, 1, "aab516d242cdba6330e9a992d37812ab205600a106e16864558b413a8a77fca2")
setManifestid(386361, "4767619368670136132", 0)


addappid(387440) -- SMITE - Ultimate God Pack
addappid(408500) -- SMITE - New Player Pack
addappid(588270) -- SMITE - 2017 Spring Split Pass + Bonus FP
addappid(793730) -- SMITE - Legend of the Foxes Senpai Bundle
addappid(795470) -- SMITE - Chinese Pantheon Chest
addappid(827380) -- SMITE - Legendary Skin Bundle
addappid(961080) -- SMITE - Arena Bundle
addappid(969570) -- SMITE - The Battleground of the Gods Bundle
addappid(969580) -- SMITE - Starter Skins Bundle
addappid(969590) -- SMITE - Best Sellers Bundle
addappid(1212080) -- SMITE - Season Pass 2020
addappid(1212090) -- SMITE - Digital Deluxe Edition 2020
addappid(1348890) -- SMITE - Avatar x SMITE Bundle
addappid(1446170) -- SMITE x TMNT Plus Bundle
addappid(1506350) -- SMITE - Season Pass 2021
addappid(1512700) -- SMITE Digital Deluxe Edition 2021
addappid(1615500) -- SMITE x Monstercat Plus Bundle
addappid(1615501) -- SMITE Gecko Guardian Bundle
addappid(1673010) -- SMITE x Stranger Things Plus Bundle
addappid(1674350) -- SMITE x Stranger Things Publisher Weekend Bundle
addappid(1781930) -- SMITE x Transformers Battle Pass Bundle
addappid(1820080) -- SMITE Curious Courier Bundle
addappid(1853620) -- SMITE Season Pass 2022
addappid(1853621) -- SMITE Digital Deluxe Edition 2022
addappid(1937190) -- SMITE Almighty Archon Bundle
addappid(2007720) -- SMITE Code Slasher Bundle
addappid(2188020) -- SMITE Stormy Chibi Susano
addappid(2222620) -- SMITE Year 10 Pass
addappid(2222630) -- SMITE Year 10 Deluxe Edition
addappid(2260390) -- SMITE - SWC 2023 Steam Giveaway
addappid(2404860) -- SMITE x VShojo Deluxe Bundle
addappid(2521930) -- SMITE x Avatar Bundle
addappid(2626990) -- SMITE x RuneScape Premium Bundle
addappid(2691160) -- SMITE Cybernetic Underworld Bundle
addappid(2691170) -- SMITE Legacy Pass
addappid(2691180) -- SMITE Deluxe Legacy Pass
addappid(2856730) -- SMITE 2 Founders Edition Cosmetics
addappid(2856740) -- SMITE 2 Deluxe Founders Edition Nightstalker Neith
addappid(2856760) -- SMITE 2 Ultimate Founders Edition The Fallen Zeus
